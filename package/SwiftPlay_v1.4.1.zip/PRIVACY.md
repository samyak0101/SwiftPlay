# Privacy Policy

SwiftPlay does not collect, store, or transmit any personal data. All functionality runs locally in your browser. No analytics, tracking, or third-party services are used. 